-- Crear bases de datos para el sistema de préstamos
CREATE DATABASE IF NOT EXISTS BD01_TRAMITACION;
CREATE DATABASE IF NOT EXISTS BD01_VALIDACIONES;

-- Mostrar las bases de datos creadas
SHOW DATABASES;
